
import os
import random
import wintab
from wintab.constants import *

class Tablet(object):
    def __init__(self, w, h, hwnd=None):
        # There is probably a much smarter way than this, but I havn't figured
        # it out yet....
        if hwnd == None:
            self.hwnd = random.randint(1024, 16777216)
        else:
            self.hwnd = int(hwnd)
        
        self.context = wintab.Context()
        # Define the type of data we want the Packets to return:
        self.context.pktdata = ( PK_X | PK_Y | PK_Z | PK_BUTTONS | PK_NORMAL_PRESSURE | 
                                 PK_ORIENTATION | PK_CURSOR)
        self.context.open(self.hwnd, True)

        self.prevBut = 0
        self.prevX = 0
        self.prevY = 0
        self.prevZ = 0
        self.prevPressure = 0
        self.prevTPressure = 0
        self.prevRot = (0,0,0)
        self.prevOrient = (0,0,0)
        self.prevTilt = 0
        self.updateScreen(w, h)

    def updateScreen(self, w, h):
        """
        Should be used if the PyGame Screen is resized to update tablet mapping.
        """
        self.screensize = (w,h)
        # Define how we need to scale our vals so they map to the pygame screen:
        self.xfactor = float(self.screensize[0]) / float(self.context.inextx)
        self.yfactor = float(self.screensize[1]) / float(self.context.inexty)

    def getData(self):
        """
        Can be called to every loop to capture the tablet info.

        return : tuple of four values:
            (int ID of button pressed, int x pos, int y pos, int pressure)
            Pressure is mapped from 0->1023
        """
        packetExtents = self.context.queuePacketsEx()
        if packetExtents[1] is not None:
            # This is a sub-list of Packet objects:
            packets = self.context.packetsGet(packetExtents[1])
            # Get the last Packet object:
            packet = packets[-1]

            # Capture packet info, and pressure data:
            buttons = packet.buttons
            x = packet.x * self.xfactor
            # Y axis is opposite for tablet and pygame:
            y = self.screensize[1] - (packet.y * self.yfactor)
            z = packet.z
            pressure = packet.normalpressure
            tilt = packet.orient_azimuth
            orient = (packet.orient_azimuth, packet.orient_altitude, packet.orient_twist)
            rot = (packet.rot_pitch, packet.rot_roll, packet.rot_yaw)
            tpressure = packet.tangentpressure
            

            # fill our "previous" values in case the user takes the pen away
            # from the PyGame screen:
            self.prevBut = buttons
            self.prevX = int(x)
            self.prevY = int(y)
            self.prevZ = int(z)
            self.prevPressure = pressure
            self.prevRot = rot
            self.prevOrient = orient
            self.prevTPressure = tpressure
            self.prevTilt = tilt
            #return (buttons, int(x), int(y), int(z), pressure, tilt)
            return (buttons, int(x), int(y), int(z), pressure, tilt) + orient + rot + (tpressure,)
        else:
            return (self.prevBut, self.prevX, self.prevY, self.prevZ, self.prevPressure, self.prevTilt) + \
                        self.prevOrient + self.prevRot + (self.prevTPressure,)

